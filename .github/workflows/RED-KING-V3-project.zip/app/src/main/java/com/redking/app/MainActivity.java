package com.redking.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final String GAME = "com.dts.freefiremax";
    private static final int BG = 0xff101118, PANEL = 0xff1b1d27,
        RED = 0xffb71936, WHITE = 0xfffaf6f6, MUTED = 0xffb9bbc8;
    private LinearLayout body;
    private TextView status;
    private boolean thai = true;
    private int dp(float n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private String tr(String th, String en) { return thai ? th : en; }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        thai = getPreferences(0).getBoolean("thai", true);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        render();
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private void add(LinearLayout target, View view, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(top); target.addView(view,p);
    }
    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18),dp(18),dp(18),dp(18)); p.setBackground(shape(PANEL,20)); return p;
    }
    private Button button(String label, int color, View.OnClickListener action) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextSize(16);
        b.setTextColor(WHITE); b.setMinHeight(dp(54)); b.setBackground(shape(color,14)); b.setOnClickListener(action); return b;
    }
    private void render() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(22),dp(24),dp(22),dp(32));
        scroll.addView(body);
        TextView edition = text("R E D  /  K I N G     •     V 3",13,0xffff8395,true); add(body,edition,0);
        ImageView logo = new ImageView(this); logo.setImageResource(com.redking.app.R.drawable.ic_king);
        logo.setContentDescription("RED KING logo"); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(84),dp(84)); lp.topMargin=dp(16); body.addView(logo,lp);
        add(body,text("RED KING",36,WHITE,true),12);
        add(body,text(tr("ศูนย์เปิดเกม • รุ่น 3.0", "Game launcher • Version 3.0"),15,MUTED,false),4);
        LinearLayout game = panel(); add(body,game,24);
        add(game,text("FREE FIRE MAX",23,WHITE,true),0);
        status = text("",15,MUTED,false); add(game,status,10);
        add(game,button(tr("เปิดเกม", "Launch game"),RED,v -> openGame()),18);
        add(game,button(tr("ตรวจสอบเกมอีกครั้ง", "Refresh game status"),0xff343746,v -> updateStatus()),10);
        LinearLayout tools = panel(); add(body,tools,14);
        add(tools,text(tr("เครื่องมือทดสอบ", "Input test"),20,WHITE,true),0);
        add(tools,text(tr("ทดสอบคีย์บอร์ดในแอปนี้ ไม่ได้ส่งคำสั่งเข้าเกม", "Test keyboard input here; no inputs are sent to the game."),14,MUTED,false),8);
        EditText field = new EditText(this); field.setSingleLine(true); field.setTextColor(WHITE); field.setHintTextColor(MUTED); field.setHint(tr("แตะแล้วลองพิมพ์", "Tap and type")); add(tools,field,10);
        add(body,button(tr("ภาษา: ไทย / English", "Language: English / ไทย"),0xff343746,v -> {
            thai = !thai; getPreferences(0).edit().putBoolean("thai",thai).apply(); render();
        }),18);
        TextView footer = text(tr("เปิดเกมตามปกติ • ไม่แก้ไขตัวเกม", "Normal launch • No game modification"),12,MUTED,false); footer.setGravity(Gravity.CENTER); add(body,footer,20);
        setContentView(scroll); updateStatus();
    }
    private Intent gameIntent() { return getPackageManager().getLaunchIntentForPackage(GAME); }
    private void updateStatus() {
        if (status != null) status.setText(gameIntent() != null ? tr("● พบเกมบนเครื่อง", "● Game detected") : tr("○ ยังไม่พบเกมบนเครื่อง", "○ Game not detected"));
    }
    @Override protected void onResume() { super.onResume(); updateStatus(); }
    private void openGame() {
        Intent intent = gameIntent();
        if (intent == null) { Toast.makeText(this,tr("ไม่พบ Free Fire MAX กรุณาติดตั้งเกมก่อน", "Free Fire MAX not found. Install the game first."),Toast.LENGTH_LONG).show(); return; }
        try { startActivity(intent); } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(this,tr("เปิดเกมไม่สำเร็จ ลองเปิดจากหน้าหลักของมือถือ", "Unable to launch. Try your phone's home screen."),Toast.LENGTH_LONG).show();
        }
    }
}
